# InternIgnite – SkillMatch (Enhanced Prototype)

A browser-based internship matching prototype built with HTML, CSS and JavaScript.

## Run the app

1. Extract the ZIP file.
2. Open `index.html` in a modern browser.
3. Choose skills, browse and filter internships, save roles, and track mock applications.

No build step or account is required. Data is stored in the browser's LocalStorage on that device.

## Automated tests

The skill-matching logic is isolated in `matching.js` and has automated unit tests.

Requirements: Node.js 18 or newer.

```bash
node --test
```

## Improvements included

- Extracted the 75/25 skill-match calculation and skill-gap logic into a reusable module.
- Added unit tests for weighting, complete matches, empty optional skills, missing skills, Set inputs and invalid data.
- Added safer validation when loading saved LocalStorage data, so malformed or outdated data does not break startup.
- Added setup and testing documentation.

## Prototype limitations

This remains a front-end student prototype. Applications are mock records; no application is sent to employers. There is no real authentication, server-side authorization, backend API or shared database. LocalStorage is device/browser-specific and must not be treated as secure storage. Internship listings and stipend benchmarks are sample data, not verified live vacancies or market statistics.

## Suggested next engineering milestone

For production use, introduce a backend API with authentication and authorization, a database, server-side input validation, and integration tests. Keep secrets and private user data off the client.
