/* Shared matching logic. Works in the browser and in Node.js tests. */
(function (root) {
  "use strict";

  function score(internship, selectedSkills) {
    if (!internship || !Array.isArray(internship.req) || !Array.isArray(internship.opt)) {
      throw new TypeError("Internship must contain req and opt skill arrays.");
    }
    const skills = selectedSkills instanceof Set ? selectedSkills : new Set(selectedSkills || []);
    const requiredScore = internship.req.length
      ? internship.req.filter(skill => skills.has(skill)).length / internship.req.length
      : 1;
    const optionalScore = internship.opt.length
      ? internship.opt.filter(skill => skills.has(skill)).length / internship.opt.length
      : 1;
    return Math.round(75 * requiredScore + 25 * optionalScore);
  }

  function missing(internship, selectedSkills) {
    if (!internship || !Array.isArray(internship.req)) {
      throw new TypeError("Internship must contain a req skill array.");
    }
    const skills = selectedSkills instanceof Set ? selectedSkills : new Set(selectedSkills || []);
    return internship.req.filter(skill => !skills.has(skill));
  }

  const api = Object.freeze({ score, missing });
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (root) root.SkillMatch = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
