const test = require('node:test');
const assert = require('node:assert/strict');
const { score, missing } = require('../matching.js');

const role = { req: ['React', 'JavaScript'], opt: ['Git', 'Docker'] };

test('returns 0 when no skills match', () => assert.equal(score(role, []), 0));
test('weights required skills at 75 percent and optional skills at 25 percent', () => {
  assert.equal(score(role, ['React']), 38);
  assert.equal(score(role, ['Git']), 13);
});
test('returns 100 when all required and optional skills match', () => {
  assert.equal(score(role, ['React', 'JavaScript', 'Git', 'Docker']), 100);
});
test('treats an empty optional-skill list as fully satisfied', () => {
  assert.equal(score({ req: ['Python'], opt: [] }, ['Python']), 100);
});
test('returns only missing required skills', () => {
  assert.deepEqual(missing(role, ['React']), ['JavaScript']);
});
test('supports Set input', () => assert.equal(score(role, new Set(['React', 'JavaScript'])), 75));
test('rejects malformed internship data', () => {
  assert.throws(() => score({ req: 'React', opt: [] }, []), TypeError);
});
